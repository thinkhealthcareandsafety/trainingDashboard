# Signs the bytes in -In with the certificate -Thumb from the Windows store (the DSC token's certificate is there);
# writes a detached CMS (PKCS#7) signature, SHA-256, to -Out.
#  -PinFile <path>: the token PIN saved by save-pin.cmd (locked to this Windows login by DPAPI) is given to the token, so
#                   no PIN window opens (owner, 28 Nov: others sign while the token is in this PC). Without it, the token's
#                   own window asks for the PIN.
#  -List:           prints the signing certificates as JSON instead.
#  -SavePin <path>: asks for the PIN here (hidden), tries one signature with it, and saves it only if that worked.
param([string]$In, [string]$Out, [string]$Thumb, [string]$PinFile, [switch]$List, [string]$SavePin)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Security

function Get-SigningCerts {
  $now = Get-Date
  @(Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.HasPrivateKey -and $_.NotAfter -gt $now -and $_.NotBefore -lt $now } | ForEach-Object {
    $eku = @($_.EnhancedKeyUsageList | ForEach-Object { $_.ObjectId })
    [pscustomobject]@{
      name = $_.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false)
      issuer = $_.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $true)
      thumbprint = $_.Thumbprint
      notAfter = $_.NotAfter.ToString("yyyy-MM-dd")
      # Document Signing (1.3.6.1.4.1.311.10.3.12) or Adobe Authentic Documents (1.2.840.113583.1.1.5)
      documentSigning = ($eku -contains "1.3.6.1.4.1.311.10.3.12") -or ($eku -contains "1.2.840.113583.1.1.5")
    }
  })
}

# The certificate with its token key opened with the PIN (no window): the CSP is logged in for this process.
function Open-WithPin($cert, [System.Security.SecureString]$pin) {
  $info = $cert.PrivateKey.CspKeyContainerInfo
  $p = New-Object System.Security.Cryptography.CspParameters -ArgumentList $info.ProviderType, $info.ProviderName, $info.KeyContainerName
  $p.KeyNumber = [int]$info.KeyNumber
  $p.Flags = [System.Security.Cryptography.CspProviderFlags]::UseExistingKey -bor [System.Security.Cryptography.CspProviderFlags]::NoPrompt
  $p.KeyPassword = $pin
  $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider -ArgumentList $p
  $copy = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList (, $cert.RawData)
  $copy.PrivateKey = $rsa
  return $copy
}

function New-Signature($cert, [byte[]]$bytes, [bool]$silent) {
  $content = New-Object System.Security.Cryptography.Pkcs.ContentInfo -ArgumentList (, $bytes)
  $cms = New-Object System.Security.Cryptography.Pkcs.SignedCms -ArgumentList $content, $true
  $signer = New-Object System.Security.Cryptography.Pkcs.CmsSigner -ArgumentList $cert
  $signer.DigestAlgorithm = New-Object System.Security.Cryptography.Oid -ArgumentList "2.16.840.1.101.3.4.2.1"
  $signer.IncludeOption = [System.Security.Cryptography.X509Certificates.X509IncludeOption]::ExcludeRoot
  [void]$signer.SignedAttributes.Add((New-Object System.Security.Cryptography.Pkcs.Pkcs9SigningTime -ArgumentList (Get-Date)))
  $cms.ComputeSignature($signer, $silent)
  return , $cms.Encode()
}

function Pick-Cert([string]$thumb) {
  if ($thumb) { return Get-Item "Cert:\CurrentUser\My\$thumb" }
  $c = Get-SigningCerts | Where-Object { $_.documentSigning } | Select-Object -First 1
  if (-not $c) { throw "No signing certificate found. Is the token plugged in?" }
  return Get-Item ("Cert:\CurrentUser\My\" + $c.thumbprint)
}

if ($List) { ConvertTo-Json -InputObject @(Get-SigningCerts) -Compress; exit 0 }

if ($SavePin) {
  $cert = Pick-Cert $Thumb
  Write-Host "Certificate: $($cert.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false))"
  Write-Host "Careful: 10 wrong PINs lock the token. This tries the PIN once."
  $pin = Read-Host -AsSecureString "Type the token PIN"
  try {
    [void](New-Signature (Open-WithPin $cert $pin) ([System.Text.Encoding]::UTF8.GetBytes("Think Health PIN check")) $true)
  } catch {
    Write-Host ""
    Write-Host "That didn't work, so nothing was saved: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
  }
  $dir = Split-Path -Parent $SavePin
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
  ConvertFrom-SecureString $pin | Set-Content -Path $SavePin -Encoding ASCII
  Write-Host ""
  Write-Host "Saved. The PIN worked without the token window, so others can now sign while the token is in this PC." -ForegroundColor Green
  exit 0
}

$cert = Pick-Cert $Thumb
if (-not $cert.HasPrivateKey) { throw "That certificate has no key here. Is the token plugged in?" }
$bytes = [System.IO.File]::ReadAllBytes($In)
if ($PinFile -and (Test-Path $PinFile)) {
  $pin = ConvertTo-SecureString (Get-Content -Path $PinFile -Raw).Trim()
  $sig = New-Signature (Open-WithPin $cert $pin) $bytes $true
} else {
  $sig = New-Signature $cert $bytes $false
}
[System.IO.File]::WriteAllBytes($Out, $sig)
