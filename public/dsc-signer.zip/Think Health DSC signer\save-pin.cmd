@echo off
rem Saves the DSC token PIN on this PC, locked to this Windows login, so the DSC signer can sign for others without the
rem PIN window. It tries the PIN once first and saves it only if it worked. Plug in the token before running this.
cd /d "%~dp0"
title Save the DSC token PIN
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sign.ps1" -SavePin "%APPDATA%\ThinkHealthDSC\pin.dat"
echo.
echo To forget the PIN later: delete %APPDATA%\ThinkHealthDSC\pin.dat
pause
