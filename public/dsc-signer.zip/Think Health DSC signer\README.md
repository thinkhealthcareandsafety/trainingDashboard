# Think Health DSC signer

Signs Invoice Converter PDFs with Sumit's DSC token (mToken CryptoID, PantaSign certificate) on the PC the token is
plugged into — for anyone who clicks **Sign with DSC**, from any computer (owner, 28 Nov).

How it works: "Sign with DSC" queues the merged PDF on the dashboard. This program asks the dashboard every 10 s
(every minute 10 pm–7 am) for the next one, draws the "Digitally signed by …" stamp under the T&C on page 1, signs it
(SHA-256, adbe.pkcs7.detached) with the certificate from the Windows store and sends it back; the dashboard puts it on
the invoice in Zoho. It only asks out. The key never leaves the token.

Setup on the PC with the token (once):
1. `install-autostart.cmd` — runs it hidden now and at every login (or `Start DSC signer.cmd` for a window).
2. Open the Invoice Converter on this PC as Sumit or Admin → **Make this PC the DSC signer** (Chrome may ask to let the
   site reach this PC: Allow).
3. `save-pin.cmd` — type the token PIN once. It tries it once and saves it only if it worked, locked to this Windows
   login (DPAPI) in `%APPDATA%\ThinkHealthDSC\pin.dat`. Without it, the token's window asks for the PIN on this PC.
   A saved PIN the token refuses is set aside at once (10 wrong PINs lock the token).

The PC must be on, logged in, with the token in. `%APPDATA%\ThinkHealthDSC\signer.log` says what it signed.
Several certificates on the PC: set `DSC_THUMB`. `sign.ps1 -List` lists certificates.
