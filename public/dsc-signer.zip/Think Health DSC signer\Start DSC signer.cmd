@echo off
rem Think Health DSC signer: keep this window open while signing (or use install-autostart.cmd to run it hidden at login).
cd /d "%~dp0"
title Think Health DSC signer
node server.mjs
pause
