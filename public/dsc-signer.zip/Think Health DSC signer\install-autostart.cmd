@echo off
rem Starts the DSC signer hidden every time you log in to Windows, and starts it now.
rem To stop it starting: delete "Think Health DSC signer" from shell:startup.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Think Health DSC signer.lnk');" ^
  "$s.TargetPath='wscript.exe'; $s.Arguments='\"%~dp0run-hidden.vbs\"'; $s.WorkingDirectory='%~dp0'; $s.Save()"
wscript.exe "%~dp0run-hidden.vbs"
echo The DSC signer is running and will start by itself at every login.
pause
